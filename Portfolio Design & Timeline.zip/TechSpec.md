# Mandlenkosi Kubheka Portfolio - Technical Specification

---

## 1. Component Inventory

### shadcn/ui Components (Built-in)
| Component | Purpose | Customization |
|-----------|---------|---------------|
| Button | CTA buttons, form submit | Custom colors, pill shape, glow effect |
| Card | Service cards, project cards | Dark theme, custom borders |
| Input | Contact form fields | Dark background, cyan focus |
| Textarea | Contact message field | Dark background, cyan focus |
| Sheet | Mobile navigation drawer | Dark theme |
| Separator | Visual dividers | Muted color |

### Third-Party Registry Components
| Component | Registry | Purpose |
|-----------|----------|---------|
| None required | - | Custom implementations preferred for this design |

### Custom Components
| Component | Props | Purpose |
|-----------|-------|---------|
| `Navbar` | `scrolled: boolean` | Fixed navigation with scroll effect |
| `HeroSection` | - | Landing section with typing animation |
| `AboutSection` | - | About me content |
| `ServicesSection` | - | Service cards grid |
| `SkillsSection` | - | Technical and professional skills |
| `ProjectsSection` | - | Project showcase |
| `ContactSection` | - | Contact form and info |
| `Footer` | - | Footer content |
| `TypingText` | `texts: string[], speed: number` | Animated typing effect |
| `NeonBorder` | `children, size` | Rotating neon border for profile |
| `ProgressBar` | `label, percentage, icon` | Animated skill bar |
| `CircularProgress` | `label, percentage` | Animated circular progress |
| `ScrollReveal` | `children, delay` | Scroll-triggered animation wrapper |
| `GlowButton` | `children, onClick` | Button with glow effect |
| `SocialIcon` | `icon, href, label` | Social media icon button |

---

## 2. Animation Implementation Table

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Page load fade-in | Framer Motion | `AnimatePresence` + initial/animate states | Low |
| Typing effect | Custom hook | `useTypingAnimation` with setInterval | Medium |
| Neon rotating border | CSS + Framer Motion | CSS animation for rotation, FM for glow pulse | Medium |
| Scroll reveal | Framer Motion | `useInView` hook + motion variants | Low |
| Progress bar fill | Framer Motion | `useInView` + animate width | Medium |
| Circular progress | Framer Motion | SVG stroke-dashoffset animation | Medium |
| Button hover glow | CSS + Framer Motion | `whileHover` scale + CSS box-shadow | Low |
| Card hover lift | Framer Motion | `whileHover` translateY + shadow | Low |
| Nav scroll effect | React state | `useScroll` hook for background change | Low |
| Smooth scroll | Native | `scroll-behavior: smooth` + scrollIntoView | Low |
| Staggered reveals | Framer Motion | `staggerChildren` in parent variants | Medium |

---

## 3. Animation Library Choices

### Primary: Framer Motion
**Rationale:**
- Best React integration for declarative animations
- Built-in `useInView` for scroll triggers
- Easy stagger animations with variants
- `AnimatePresence` for mount/unmount animations
- Excellent TypeScript support

### Secondary: CSS Animations
**Used for:**
- Continuous animations (neon border rotation)
- Simple hover transitions
- Performance-critical micro-interactions

### Custom Hooks
| Hook | Purpose |
|------|---------|
| `useTypingAnimation` | Typing effect for hero text |
| `useScrollPosition` | Track scroll for navbar effect |
| `useInViewAnimation` | Reusable scroll-triggered animation |

---

## 4. Project File Structure

```
/mnt/okcomputer/output/app/
├── public/
│   └── images/
│       ├── profile.jpg
│       ├── about.jpg
│       ├── project1.jpg
│       ├── project2.jpg
│       └── project3.jpg
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn components
│   │   ├── Navbar.tsx
│   │   ├── TypingText.tsx
│   │   ├── NeonBorder.tsx
│   │   ├── ProgressBar.tsx
│   │   ├── CircularProgress.tsx
│   │   ├── ScrollReveal.tsx
│   │   ├── GlowButton.tsx
│   │   └── SocialIcon.tsx
│   ├── sections/
│   │   ├── HeroSection.tsx
│   │   ├── AboutSection.tsx
│   │   ├── ServicesSection.tsx
│   │   ├── SkillsSection.tsx
│   │   ├── ProjectsSection.tsx
│   │   ├── ContactSection.tsx
│   │   └── Footer.tsx
│   ├── hooks/
│   │   ├── useTypingAnimation.ts
│   │   ├── useScrollPosition.ts
│   │   └── useInViewAnimation.ts
│   ├── lib/
│   │   └── utils.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── components.json
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

---

## 5. Dependencies

### Core Dependencies (from shadcn init)
- react
- react-dom
- typescript
- vite
- tailwindcss
- @radix-ui/react-* (various)
- class-variance-authority
- clsx
- tailwind-merge
- lucide-react

### Additional Dependencies
| Package | Version | Purpose |
|---------|---------|---------|
| framer-motion | ^11.0.0 | Animations |

### Installation Commands
```bash
# Initialize project
bash /app/.kimi/skills/webapp-building/scripts/init-webapp.sh "Mandlenkosi Kubheka Portfolio"

# Install animation library
npm install framer-motion

# Add shadcn components
npx shadcn add button card input textarea sheet separator
```

---

## 6. Key Implementation Details

### Neon Border Animation
```css
@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.neon-border {
  background: conic-gradient(from 0deg, #00d4ff, #a855f7, #00d4ff);
  animation: rotate 4s linear infinite;
}
```

### Typing Animation Hook
```typescript
function useTypingAnimation(texts: string[], speed: number = 100) {
  const [displayText, setDisplayText] = useState('');
  const [textIndex, setTextIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Implementation with setInterval
  // Handles typing, pausing, deleting, and cycling
}
```

### Scroll Reveal Variants
```typescript
const revealVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: [0.645, 0.045, 0.355, 1] }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};
```

### Progress Bar Animation
```typescript
// Using Framer Motion's useInView and animate
const ProgressBar = ({ percentage }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  
  return (
    <motion.div
      ref={ref}
      initial={{ width: 0 }}
      animate={isInView ? { width: `${percentage}%` } : { width: 0 }}
      transition={{ duration: 1.5, ease: "easeOut" }}
    />
  );
};
```

---

## 7. Performance Considerations

- Use `will-change` on animated elements
- Implement `prefers-reduced-motion` media query
- Lazy load images below the fold
- Use CSS transforms instead of layout properties
- Debounce scroll event handlers
- Use `useInView` with `once: true` for one-time animations

---

## 8. Accessibility

- All animations respect `prefers-reduced-motion`
- Focus states visible on all interactive elements
- Color contrast meets WCAG AA standards
- Semantic HTML structure
- Alt text for all images
- Keyboard navigation support
