import { motion } from 'framer-motion';
import { ScrollReveal } from '@/components/ScrollReveal';
import { ProgressBar } from '@/components/ProgressBar';
import { CircularProgress } from '@/components/CircularProgress';
import { Server, Network, Monitor, Code, Database, Cpu } from 'lucide-react';

const technicalSkills = [
  { label: 'Server Assembly', percentage: 95, icon: Server },
  { label: 'Networking', percentage: 90, icon: Network },
  { label: 'Windows Server', percentage: 85, icon: Monitor },
  { label: 'Python', percentage: 75, icon: Code },
  { label: 'Data Scraping', percentage: 80, icon: Database },
  { label: 'Hardware Troubleshooting', percentage: 90, icon: Cpu },
];

const professionalSkills = [
  { label: 'Problem Solving', percentage: 90 },
  { label: 'Teamwork', percentage: 85 },
  { label: 'Communication', percentage: 80 },
  { label: 'Adaptability', percentage: 85 },
];

const skillImages = [
  { src: '/images/packet-tracer.jpg', alt: 'Working with VMware Virtual Machines' },
  { src: '/images/basic-electrical.jpg', alt: 'Basic Electrical Work' },
  { src: '/images/electronics.jpg', alt: 'Electronics Projects' },
];

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 lg:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-navy-400" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <ScrollReveal className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            My <span className="text-cyan-400">Skills</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A comprehensive overview of my technical expertise and professional competencies 
            developed through years of hands-on experience.
          </p>
        </ScrollReveal>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Technical Skills */}
          <ScrollReveal direction="left">
            <div>
              <h3 className="text-2xl font-semibold text-foreground mb-8 text-center lg:text-left">
                Technical Skills
              </h3>
              <div>
                {technicalSkills.map((skill, index) => (
                  <ProgressBar
                    key={skill.label}
                    label={skill.label}
                    percentage={skill.percentage}
                    icon={skill.icon}
                    delay={index * 0.15}
                  />
                ))}
              </div>
            </div>
          </ScrollReveal>
          
          {/* Professional Skills */}
          <ScrollReveal direction="right">
            <div>
              <h3 className="text-2xl font-semibold text-foreground mb-8 text-center lg:text-left">
                Professional Skills
              </h3>
              <div className="grid grid-cols-2 gap-8">
                {professionalSkills.map((skill, index) => (
                  <CircularProgress
                    key={skill.label}
                    label={skill.label}
                    percentage={skill.percentage}
                    delay={index * 0.2}
                  />
                ))}
              </div>
            </div>
          </ScrollReveal>
        </div>
        
        {/* Skills in Action Gallery */}
        <ScrollReveal delay={0.3} className="mt-16">
          <h4 className="text-lg font-semibold text-foreground mb-6 text-center">
            Skills in Action
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {skillImages.map((image, index) => (
              <motion.div
                key={image.src}
                className="relative aspect-video rounded-xl overflow-hidden group"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-500/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <p className="text-white text-sm font-medium">{image.alt}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </ScrollReveal>
        
        {/* Additional Skills Tags */}
        <ScrollReveal delay={0.5} className="mt-16">
          <div className="text-center">
            <h4 className="text-lg font-semibold text-foreground mb-6">
              Additional Technologies & Tools
            </h4>
            <div className="flex flex-wrap justify-center gap-3">
              {[
                'RAID Configuration',
                'VMware',
                'Cisco Packet Tracer',
                'Tableau',
                'VB.Net',
                'Microsoft Office Suite',
                'BIOS/UEFI',
                'Linux',
                'Data Visualization',
                'Quality Control',
              ].map((skill) => (
                <span
                  key={skill}
                  className="px-4 py-2 bg-navy-200 border border-cyan-400/20 rounded-full text-sm text-muted-foreground hover:border-cyan-400/50 hover:text-cyan-400 transition-colors duration-300"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
