import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { ScrollReveal } from '@/components/ScrollReveal';
import { Briefcase, GraduationCap, Calendar, MapPin } from 'lucide-react';

interface TimelineItem {
  id: number;
  type: 'education' | 'work';
  title: string;
  organization: string;
  location: string;
  period: string;
  description: string;
  highlights?: string[];
}

const timelineData: TimelineItem[] = [
  {
    id: 1,
    type: 'work',
    title: 'IT Technician (Server Assembly & Testing)',
    organization: 'Mustek Limited',
    location: 'Midrand, South Africa',
    period: 'June 2022 – Present',
    description: 'Responsible for the complete lifecycle of server units from assembly to deployment.',
    highlights: [
      'Assemble and test server machines (Lenovo rackmount/desktop, Mecer desktop)',
      'Perform RAID deployment, BIOS/UEFI updates, and component burn-in testing',
      'Load standard and custom client OS images and generate Computer Build Reports',
      'Conduct hardware upgrades on notebooks and laptops',
      'Point of sale hardware upgrades and software updates'
    ]
  },
  {
    id: 2,
    type: 'education',
    title: 'Mathematics and Statistics',
    organization: 'University of South Africa (UNISA)',
    location: 'Johannesburg, South Africa',
    period: '2025 – Present',
    description: 'Pursuing part-time studies to continuously expand theoretical knowledge.',
  },
  {
    id: 3,
    type: 'work',
    title: 'E-Cadre (PYIE)',
    organization: 'Kwa-Thema Primary School',
    location: 'Kwa-Thema, South Africa',
    period: 'February 2021 – May 2021',
    description: 'Provided comprehensive technical support to school staff.',
    highlights: [
      'Troubleshooting hardware, software, and network issues',
      'Set up and configured department-issued laptops for staff use',
      'Managed printer maintenance including toner replacement',
      'Compiled and submitted daily COVID-19 statistics and monthly pay slips'
    ]
  },
  {
    id: 4,
    type: 'work',
    title: 'Examination Assistant (Brigade)',
    organization: 'Ekurhuleni East TVET College',
    location: 'Springs, South Africa',
    period: 'September 2020 – December 2020',
    description: 'Supported examination processes during COVID-19 pandemic.',
    highlights: [
      'Enforced COVID-19 regulations and ensured venue compliance',
      'Captured and compiled daily statistics and reports for COVID-19 monitoring'
    ]
  },
  {
    id: 5,
    type: 'education',
    title: 'Big Data Technology and Application',
    organization: 'Chongqing Industrial Polytechnic College',
    location: 'Chongqing, China',
    period: '2019 – 2020',
    description: 'International internship focusing on big data and networking.',
    highlights: [
      'Worked on data scraping and web crawling projects',
      'Represented South Africa in BRICS Skills Competition - Bronze Medal',
      'Processed and managed datasets of over 2 million records using Tableau'
    ]
  },
  {
    id: 6,
    type: 'education',
    title: 'Information Technology and Computer Science NCV L2–L4',
    organization: 'Ekurhuleni East TVET College',
    location: 'Springs, South Africa',
    period: '2018',
    description: 'Comprehensive IT education with practical competitions.',
    highlights: [
      'Participated in WorldSkills South Africa for IT Network Administration',
      'Designed and configured complex corporate and IoT networks using Cisco Packet Tracer',
      'Managed multi-platform environments through VMware'
    ]
  },
  {
    id: 7,
    type: 'education',
    title: 'National Senior Certificate',
    organization: 'Kenneth Masekela Secondary School',
    location: 'Kwa-Thema, South Africa',
    period: '2013',
    description: 'Completed secondary education.',
  }
];

function TimelineCard({ item, index }: { item: TimelineItem; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const isEven = index % 2 === 0;

  const Icon = item.type === 'education' ? GraduationCap : Briefcase;
  const iconColor = item.type === 'education' ? 'text-purple-400' : 'text-cyan-400';
  const bgColor = item.type === 'education' ? 'bg-purple-500/10' : 'bg-cyan-500/10';
  const borderColor = item.type === 'education' ? 'border-purple-400/30' : 'border-cyan-400/30';

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: isEven ? -50 : 50 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.645, 0.045, 0.355, 1] }}
      className={`relative flex items-center gap-8 ${isEven ? 'flex-row' : 'flex-row-reverse'} mb-12 last:mb-0`}
    >
      {/* Content Card */}
      <div className={`flex-1 ${isEven ? 'text-right pr-8' : 'text-left pl-8'}`}>
        <motion.div
          className={`inline-block p-6 rounded-xl bg-card border ${borderColor} hover:border-opacity-60 transition-all duration-300`}
          whileHover={{ y: -5, boxShadow: '0 10px 40px rgba(0, 212, 255, 0.1)' }}
        >
          {/* Type Badge */}
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${bgColor} ${iconColor} text-sm font-medium mb-3 ${isEven ? 'flex-row-reverse' : ''}`}>
            <Icon className="w-4 h-4" />
            <span className="capitalize">{item.type}</span>
          </div>

          {/* Title */}
          <h3 className="text-xl font-semibold text-foreground mb-1">
            {item.title}
          </h3>

          {/* Organization */}
          <p className="text-cyan-400 font-medium mb-2">
            {item.organization}
          </p>

          {/* Period & Location */}
          <div className={`flex items-center gap-4 text-sm text-muted-foreground mb-3 ${isEven ? 'justify-end' : ''}`}>
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {item.period}
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              {item.location}
            </span>
          </div>

          {/* Description */}
          <p className="text-muted-foreground text-sm mb-3">
            {item.description}
          </p>

          {/* Highlights */}
          {item.highlights && item.highlights.length > 0 && (
            <ul className={`space-y-1 ${isEven ? 'text-right' : 'text-left'}`}>
              {item.highlights.map((highlight, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${item.type === 'education' ? 'bg-purple-400' : 'bg-cyan-400'} mt-1.5 flex-shrink-0`} />
                  <span>{highlight}</span>
                </li>
              ))}
            </ul>
          )}
        </motion.div>
      </div>

      {/* Center Icon */}
      <div className="relative z-10 flex-shrink-0">
        <motion.div
          className={`w-14 h-14 rounded-full ${bgColor} border-2 ${borderColor} flex items-center justify-center`}
          initial={{ scale: 0 }}
          animate={isInView ? { scale: 1 } : {}}
          transition={{ duration: 0.4, delay: index * 0.1 + 0.2 }}
        >
          <Icon className={`w-6 h-6 ${iconColor}`} />
        </motion.div>
      </div>

      {/* Empty Space for Alternating Layout */}
      <div className="flex-1" />
    </motion.div>
  );
}

function TimelineCardMobile({ item, index }: { item: TimelineItem; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const Icon = item.type === 'education' ? GraduationCap : Briefcase;
  const iconColor = item.type === 'education' ? 'text-purple-400' : 'text-cyan-400';
  const bgColor = item.type === 'education' ? 'bg-purple-500/10' : 'bg-cyan-500/10';
  const borderColor = item.type === 'education' ? 'border-purple-400/30' : 'border-cyan-400/30';

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -30 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="relative pl-8 pb-10 last:pb-0"
    >
      {/* Timeline Line */}
      <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-400 via-purple-400 to-cyan-400" />

      {/* Icon */}
      <motion.div
        className={`absolute left-0 top-0 w-6 h-6 rounded-full ${bgColor} border-2 ${borderColor} flex items-center justify-center`}
        initial={{ scale: 0 }}
        animate={isInView ? { scale: 1 } : {}}
        transition={{ duration: 0.3, delay: index * 0.1 + 0.1 }}
      >
        <Icon className={`w-3 h-3 ${iconColor}`} />
      </motion.div>

      {/* Card */}
      <motion.div
        className={`p-5 rounded-xl bg-card border ${borderColor}`}
        whileHover={{ y: -3 }}
      >
        {/* Type Badge */}
        <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${bgColor} ${iconColor} text-sm font-medium mb-3`}>
          <Icon className="w-4 h-4" />
          <span className="capitalize">{item.type}</span>
        </div>

        {/* Title */}
        <h3 className="text-lg font-semibold text-foreground mb-1">
          {item.title}
        </h3>

        {/* Organization */}
        <p className="text-cyan-400 font-medium mb-2">
          {item.organization}
        </p>

        {/* Period & Location */}
        <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground mb-3">
          <span className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            {item.period}
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="w-4 h-4" />
            {item.location}
          </span>
        </div>

        {/* Description */}
        <p className="text-muted-foreground text-sm mb-3">
          {item.description}
        </p>

        {/* Highlights */}
        {item.highlights && item.highlights.length > 0 && (
          <ul className="space-y-1">
            {item.highlights.map((highlight, i) => (
              <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                <span className={`w-1.5 h-1.5 rounded-full ${item.type === 'education' ? 'bg-purple-400' : 'bg-cyan-400'} mt-1.5 flex-shrink-0`} />
                <span>{highlight}</span>
              </li>
            ))}
          </ul>
        )}
      </motion.div>
    </motion.div>
  );
}

export function TimelineSection() {
  return (
    <section id="experience" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-navy-300" />

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-72 h-72 bg-purple-500/5 rounded-full blur-3xl" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <ScrollReveal className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Education & <span className="text-cyan-400">Experience</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My professional journey and educational background that has shaped my career in IT.
          </p>
        </ScrollReveal>

        {/* Desktop Timeline */}
        <div className="hidden md:block relative">
          {/* Center Line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-400 via-purple-400 to-cyan-400 transform -translate-x-1/2" />

          {/* Timeline Items */}
          {timelineData.map((item, index) => (
            <TimelineCard key={item.id} item={item} index={index} />
          ))}
        </div>

        {/* Mobile Timeline */}
        <div className="md:hidden">
          {timelineData.map((item, index) => (
            <TimelineCardMobile key={item.id} item={item} index={index} />
          ))}
        </div>

        {/* Certifications Banner */}
        <ScrollReveal delay={0.5} className="mt-16">
          <div className="bg-card border border-cyan-400/20 rounded-xl p-8 text-center">
            <h3 className="text-2xl font-semibold text-foreground mb-6">
              Professional <span className="text-cyan-400">Certifications</span>
            </h3>
            <div className="flex flex-wrap justify-center gap-4">
              {[
                { name: 'CompTIA A+', year: '2023' },
                { name: 'CompTIA Security+', year: '2025' },
                { name: 'CompTIA Server+', year: '2025' },
                { name: 'Technical Support NQF4', year: '2022' },
                { name: 'Cisco Packet Tracer', year: '2018' },
              ].map((cert) => (
                <div
                  key={cert.name}
                  className="px-5 py-3 bg-navy-200 border border-cyan-400/30 rounded-lg"
                >
                  <p className="text-foreground font-medium">{cert.name}</p>
                  <p className="text-cyan-400 text-sm">{cert.year}</p>
                </div>
              ))}
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
