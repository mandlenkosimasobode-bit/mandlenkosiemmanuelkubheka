import { ScrollReveal } from '@/components/ScrollReveal';
import { NeonBorder } from '@/components/NeonBorder';
import { GlowButton } from '@/components/GlowButton';

export function AboutSection() {
  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top + window.scrollY;
      window.scrollTo({
        top: elementPosition - offset,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="about" className="py-20 lg:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-navy-400" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          {/* Left - Image */}
          <ScrollReveal direction="left" className="flex-1 flex justify-center">
            <NeonBorder size={350}>
              <img
                src="/images/hardware-software.jpg"
                alt="Mandlenkosi working with computer hardware"
                className="w-full h-full object-cover"
              />
            </NeonBorder>
          </ScrollReveal>
          
          {/* Right - Content */}
          <div className="flex-1">
            <ScrollReveal direction="right">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
                About <span className="text-cyan-400">Me</span>
              </h2>
            </ScrollReveal>
            
            <ScrollReveal direction="right" delay={0.1}>
              <h3 className="text-xl sm:text-2xl font-semibold text-foreground mb-6">
                IT Professional & Server Specialist
              </h3>
            </ScrollReveal>
            
            <ScrollReveal direction="right" delay={0.2}>
              <div className="space-y-4 text-muted-foreground leading-relaxed mb-8">
                <p>
                  I am a dedicated IT professional with a solid foundation in information technology from 
                  Ekurhuleni East TVET College, complemented by industry-recognized CompTIA certifications 
                  and hands-on experience in hardware assembly, system testing, and network administration.
                </p>
                <p>
                  My participation in World Skills South Africa for IT Network Administration and representing 
                  South Africa in the BRICS Skills Competition (where my team secured a bronze medal) has honed 
                  my skills in virtualization, network simulation, and multi-platform environment management.
                </p>
                <p>
                  Currently at Mustek Limited, I am responsible for the complete lifecycle of server units - 
                  from precise hardware assembly to rigorous testing and deployment. I hold CompTIA A+, Security+, 
                  and Server+ certifications, and I'm continuously expanding my expertise through part-time studies at UNISA.
                </p>
              </div>
            </ScrollReveal>
            
            {/* Certifications */}
            <ScrollReveal direction="right" delay={0.3}>
              <div className="mb-8">
                <h4 className="text-lg font-semibold text-foreground mb-4">Certifications</h4>
                <div className="flex flex-wrap gap-3">
                  {['CompTIA A+', 'CompTIA Security+', 'CompTIA Server+', 'Cisco Packet Tracer'].map((cert) => (
                    <span 
                      key={cert}
                      className="px-4 py-2 bg-navy-200 border border-cyan-400/30 rounded-full text-sm text-cyan-400"
                    >
                      {cert}
                    </span>
                  ))}
                </div>
              </div>
            </ScrollReveal>
            
            <ScrollReveal direction="right" delay={0.4}>
              <GlowButton onClick={scrollToContact}>
                Let's Talk
              </GlowButton>
            </ScrollReveal>
          </div>
        </div>
      </div>
    </section>
  );
}
