import { motion } from 'framer-motion';
import { ScrollReveal } from '@/components/ScrollReveal';
import { ExternalLink } from 'lucide-react';

interface ProjectCardProps {
  image: string;
  title: string;
  description: string;
  tags: string[];
  delay: number;
}

function ProjectCard({ image, title, description, tags, delay }: ProjectCardProps) {
  return (
    <ScrollReveal delay={delay}>
      <motion.div
        className="project-card bg-card rounded-xl overflow-hidden group cursor-pointer"
        whileHover={{ y: -8 }}
        transition={{ duration: 0.3 }}
      >
        <div className="relative aspect-video overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
          />
          <div className="overlay flex flex-col justify-end p-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileHover={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="text-xl font-semibold text-foreground mb-2">{title}</h3>
              <p className="text-muted-foreground text-sm mb-4">{description}</p>
              <div className="flex items-center gap-2 text-cyan-400">
                <span className="text-sm font-medium">View Project</span>
                <ExternalLink className="w-4 h-4" />
              </div>
            </motion.div>
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-cyan-400 transition-colors">
            {title}
          </h3>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 bg-navy-200 rounded-full text-xs text-muted-foreground"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </ScrollReveal>
  );
}

const projects = [
  {
    image: '/images/project1.jpg',
    title: 'Quality Control - Mecer Notebooks',
    description: 'Led a team of three technicians to rework and test 3,500+ Mecer notebooks to meet quality standards at Mustek Limited.',
    tags: ['Quality Control', 'Hardware Testing', 'Team Leadership'],
  },
  {
    image: '/images/brics-award.jpg',
    title: 'BRICS Data Processing',
    description: 'Processed and managed a large dataset of over 2 million records using Tableau, presenting data in graphical formats for the BRICS Competition in China.',
    tags: ['Data Analysis', 'Tableau', 'Python'],
  },
  {
    image: '/images/lab1.jpg',
    title: 'Network Infrastructure Setup',
    description: 'Designed and configured complex corporate and IoT networks using Cisco Packet Tracer for WorldSkills competition.',
    tags: ['Networking', 'Cisco', 'IoT'],
  },
];

const labImages = [
  { src: '/images/lab2.jpg', alt: 'Network cable installation' },
  { src: '/images/lab3.jpg', alt: 'Server rack setup' },
  { src: '/images/lab4.jpg', alt: 'Network equipment installation' },
  { src: '/images/lab5.jpg', alt: 'Lab infrastructure work' },
];

export function ProjectsSection() {
  return (
    <section id="projects" className="py-20 lg:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-navy-300" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <ScrollReveal className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            Latest <span className="text-cyan-400">Projects</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A showcase of my professional work, competitions, and key achievements 
            in the IT industry.
          </p>
        </ScrollReveal>
        
        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={project.title}
              {...project}
              delay={index * 0.1}
            />
          ))}
        </div>
        
        {/* Lab Installation Gallery */}
        <ScrollReveal delay={0.4} className="mt-16">
          <div className="bg-card border border-cyan-400/20 rounded-xl p-8">
            <h3 className="text-2xl font-semibold text-foreground mb-2 text-center">
              Lab <span className="text-cyan-400">Installation Gallery</span>
            </h3>
            <p className="text-muted-foreground text-center mb-6">
              Photos from network infrastructure and lab setup projects
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {labImages.map((image, index) => (
                <motion.div
                  key={image.src}
                  className="relative aspect-square rounded-lg overflow-hidden group"
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05 }}
                >
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-navy-500/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <p className="text-white text-xs text-center px-2">{image.alt}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </ScrollReveal>
        
        {/* Achievements */}
        <ScrollReveal delay={0.5} className="mt-16">
          <div className="bg-card border border-cyan-400/20 rounded-xl p-8">
            <h3 className="text-2xl font-semibold text-foreground mb-6 text-center">
              Key <span className="text-cyan-400">Achievements</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-cyan-400 mb-2">3,500+</div>
                <p className="text-muted-foreground">Devices Tested & Reworked</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-cyan-400 mb-2">Bronze</div>
                <p className="text-muted-foreground">BRICS Skills Competition Medal</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-cyan-400 mb-2">2M+</div>
                <p className="text-muted-foreground">Records Processed</p>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
