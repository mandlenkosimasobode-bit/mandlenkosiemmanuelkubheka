import { motion } from 'framer-motion';
import { ScrollReveal } from '@/components/ScrollReveal';
import { Server, Network, Wrench, ArrowRight } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  image: string;
  delay: number;
}

function ServiceCard({ icon: Icon, title, description, image, delay }: ServiceCardProps) {
  return (
    <ScrollReveal delay={delay}>
      <motion.div
        className="service-card bg-card rounded-xl h-full overflow-hidden"
        whileHover={{ y: -8 }}
        transition={{ duration: 0.3 }}
      >
        {/* Service Image */}
        <div className="h-48 overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
        </div>
        
        <div className="p-8">
          <div className="w-14 h-14 bg-cyan-500/10 rounded-lg flex items-center justify-center mb-6">
            <Icon className="w-7 h-7 text-cyan-400" />
          </div>
          
          <h3 className="text-xl font-semibold text-foreground mb-4">{title}</h3>
          
          <p className="text-muted-foreground leading-relaxed mb-6">
            {description}
          </p>
          
          <motion.a
            href="#contact"
            className="inline-flex items-center gap-2 text-cyan-400 font-medium group"
            whileHover={{ x: 5 }}
          >
            Learn More
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </motion.a>
        </div>
      </motion.div>
    </ScrollReveal>
  );
}

const services = [
  {
    icon: Server,
    title: 'Server Assembly & Testing',
    description: 'Expert server assembly for Lenovo and Mecer systems, including RAID deployment, BIOS/UEFI updates, and comprehensive burn-in testing to ensure hardware quality and reliability.',
    image: '/images/computer-diagnosis.jpg',
  },
  {
    icon: Network,
    title: 'Network Administration',
    description: 'Network design and configuration using Cisco Packet Tracer, Windows Server setup, router and switch management, and complete LAN/WAN infrastructure deployment.',
    image: '/images/lab2.jpg',
  },
  {
    icon: Wrench,
    title: 'Technical Support',
    description: 'Comprehensive IT support including hardware troubleshooting, software installation, system diagnostics, and end-user training for optimal technology utilization.',
    image: '/images/virtual-machines.jpg',
  },
];

export function ServicesSection() {
  return (
    <section id="services" className="py-20 lg:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-navy-300" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <ScrollReveal className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            My <span className="text-cyan-400">Services</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Professional IT services tailored to meet your technology needs, 
            from server infrastructure to network solutions.
          </p>
        </ScrollReveal>
        
        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={service.title}
              {...service}
              delay={index * 0.1}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
