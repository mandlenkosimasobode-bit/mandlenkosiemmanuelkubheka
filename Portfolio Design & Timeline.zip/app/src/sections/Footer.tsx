import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-8 relative border-t border-white/10">
      {/* Background */}
      <div className="absolute inset-0 bg-navy-500" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="text-muted-foreground text-sm text-center md:text-left"
          >
            © {currentYear} Mandlenkosi Kubheka. All rights reserved.
          </motion.p>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-muted-foreground text-sm flex items-center gap-1"
          >
            Designed with <Heart className="w-4 h-4 text-cyan-400 fill-cyan-400" /> for IT excellence
          </motion.p>
        </div>
      </div>
    </footer>
  );
}
