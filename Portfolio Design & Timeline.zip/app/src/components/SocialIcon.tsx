import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';

interface SocialIconProps {
  icon: LucideIcon;
  href: string;
  label: string;
}

export function SocialIcon({ icon: Icon, href, label }: SocialIconProps) {
  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="relative w-10 h-10 flex items-center justify-center rounded-full border-2 border-cyan-400 text-cyan-400 transition-colors duration-300 hover:text-navy-400 overflow-hidden group"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
    >
      <span className="absolute inset-0 bg-cyan-400 transform scale-0 group-hover:scale-100 transition-transform duration-300 rounded-full" />
      <Icon className="w-4 h-4 relative z-10" />
    </motion.a>
  );
}
