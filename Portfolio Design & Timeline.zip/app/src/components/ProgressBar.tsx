import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import type { LucideIcon } from 'lucide-react';

interface ProgressBarProps {
  label: string;
  percentage: number;
  icon?: LucideIcon;
  delay?: number;
}

export function ProgressBar({ label, percentage, icon: Icon, delay = 0 }: ProgressBarProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <div ref={ref} className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          {Icon && <Icon className="w-5 h-5 text-cyan-400" />}
          <span className="text-foreground font-medium">{label}</span>
        </div>
        <span className="text-cyan-400 font-semibold">{percentage}%</span>
      </div>
      <div className="h-2 bg-navy-100 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-cyan-500 to-cyan-400 rounded-full"
          initial={{ width: 0 }}
          animate={isInView ? { width: `${percentage}%` } : { width: 0 }}
          transition={{ 
            duration: 1.5, 
            delay,
            ease: "easeOut" 
          }}
        />
      </div>
    </div>
  );
}
