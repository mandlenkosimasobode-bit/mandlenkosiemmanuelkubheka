import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

interface NeonBorderProps {
  children: ReactNode;
  size?: number;
  className?: string;
}

export function NeonBorder({ children, size = 300, className = '' }: NeonBorderProps) {
  return (
    <div 
      className={`relative inline-block ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Rotating gradient border */}
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{
          background: 'conic-gradient(from 0deg, #00d4ff, #a855f7, #00d4ff)',
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
      />
      
      {/* Inner content container */}
      <div 
        className="absolute inset-[4px] rounded-full overflow-hidden bg-navy-400"
        style={{
          boxShadow: 'inset 0 0 30px rgba(0, 212, 255, 0.2)',
        }}
      >
        {children}
      </div>
      
      {/* Glow effect */}
      <motion.div
        className="absolute inset-0 rounded-full pointer-events-none"
        animate={{
          boxShadow: [
            '0 0 20px rgba(0, 212, 255, 0.4), 0 0 40px rgba(0, 212, 255, 0.2)',
            '0 0 30px rgba(0, 212, 255, 0.6), 0 0 60px rgba(0, 212, 255, 0.3)',
            '0 0 20px rgba(0, 212, 255, 0.4), 0 0 40px rgba(0, 212, 255, 0.2)',
          ],
        }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}
