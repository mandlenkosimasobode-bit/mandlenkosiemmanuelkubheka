import { useTypingAnimation } from '@/hooks/useTypingAnimation';

interface TypingTextProps {
  texts: string[];
  className?: string;
  typingSpeed?: number;
  deletingSpeed?: number;
  pauseDuration?: number;
}

export function TypingText({ 
  texts, 
  className = '',
  typingSpeed = 100,
  deletingSpeed = 50,
  pauseDuration = 2000
}: TypingTextProps) {
  const displayText = useTypingAnimation(texts, typingSpeed, deletingSpeed, pauseDuration);

  return (
    <span className={className}>
      {displayText}
      <span className="animate-caret-blink">|</span>
    </span>
  );
}
